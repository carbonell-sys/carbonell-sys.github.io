---
name: web-optimizer
description: This skill should be used when optimizing and improving the design of websites built with the Python+Jinja2 static site generator boilerplate system. It provides a systematic workflow for analyzing design issues, replicating professional layouts, fixing CSS/HTML structural problems, and iterating until achieving a professional appearance that matches reference designs or industry standards.
---

# Web Optimizer Skill

## Overview

This skill enables systematic optimization of websites built with the Python+Jinja2 static site generator boilerplate. It transforms sites with design issues (broken layouts, poor spacing, unprofessional appearance) into polished, professional websites by analyzing current design against standards, identifying specific issues, applying proven CSS/HTML solutions, and iterating with visual validation until achieving professional quality.

## When to Use This Skill

Use this skill when working with sites in the `web_boilerplate` repository structure and encountering:

- **Layout Issues**: Header text breaking into multiple lines, navigation not horizontal, content misaligned
- **Spacing Problems**: Excessive empty space, text pushed to one side, inconsistent margins/padding
- **Professional Design Gaps**: Need to replicate an existing professional site's design
- **Banner/Hero Issues**: Images not full-width, constrained by containers incorrectly
- **Typography Problems**: Poor hierarchy, inconsistent sizing, low readability
- **Color Scheme**: Non-professional colors, poor contrast, wrong sector branding
- **Responsive Issues**: Layout breaks on different screen sizes

## Boilerplate Architecture

Sites are located in `sites/{sitename}/src/` with this structure:

```
sites/{sitename}/src/
├── content/{lang}/          # HTML content files per language
├── templates/
│   ├── base.html           # Main layout template
│   └── components/         # Header, footer, cookie banner
├── static/
│   ├── css/
│   │   ├── variables.css   # Design tokens (FIRST in cascade)
│   │   ├── reset.css       # Typography baseline (SECOND)
│   │   ├── main.css        # Layout & structure (THIRD)
│   │   ├── components.css  # Components + utilities (FOURTH)
│   │   └── print.css       # Print styles (LAST)
│   ├── js/                 # JavaScript modules
│   └── images/             # Static assets
└── data/
    ├── config.json         # Site settings
    ├── ui-strings.json     # UI translations
    ├── navigation.json     # Menu structure
    └── page-metadata.json  # SEO metadata
```

**CSS Concatenation Order Matters**: Files are concatenated in the exact order above. Variables must come first to be available to all other files.

**For detailed architecture**, see `references/boilerplate-architecture.md`.

## Optimization Workflow

### Step 1: Analyze Current Design

1. Navigate to the site locally or online
2. Take full-page screenshots using Playwright
3. If reference design exists, capture screenshots for comparison
4. Document current state with specific observations

### Step 2: Compare with Reference

If replicating an existing design:

1. Open reference site and capture screenshots
2. Side-by-side comparison of header, navigation, hero, content, typography, colors
3. Create detailed comparison notes:

```markdown
CURRENT vs REFERENCE:
❌ Header: Text in multiple lines vs ✅ Single horizontal line
❌ Navigation: Missing vs ✅ Dark blue horizontal bar
❌ Banner: Small centered vs ✅ Full-width
```

### Step 3: Identify Specific Issues

Create a comprehensive checklist covering header/navigation, hero/banner, content layout, typography, colors, and spacing.

See `references/optimization-workflow.md` for complete checklist template.

### Step 4: Use UI/UX Designer Agent

Invoke the specialized `ui-ux-designer` subagent with detailed requirements:

```markdown
Use Task tool with subagent_type: "ui-ux-designer"

I need you to completely redesign the CSS for {sitename} to match {reference}.

**CRITICAL DESIGN REQUIREMENTS:**
1. HEADER LAYOUT: [specific requirements]
2. NAVIGATION BAR: [specific requirements]
3. HERO BANNER: [specific requirements]
4. CONTENT LAYOUT: [specific requirements]
5. TYPOGRAPHY: [specific requirements]
6. SPACING: [specific requirements]

**CURRENT PROBLEMS TO FIX:**
❌ [List all issues from Step 3]

**FILES TO MODIFY:**
sites/{sitename}/src/static/css/
- variables.css, main.css, components.css, reset.css

**EXPECTED RESULT:**
✅ [List all desired outcomes]

Return the complete updated CSS files.
```

### Step 5: Fix HTML Structure Issues

After CSS updates, check if HTML structure needs changes:

**Common issue: Banner not full-width**

Move banner outside container:

```html
<!-- BEFORE (constrained) -->
<section class="hero">
  <div class="container">
    <img src="/assets/images/banner.jpg">

<!-- AFTER (full-width) -->
<section class="hero">
  <img src="/assets/images/banner.jpg" class="hero-banner">
  <div class="container">
```

### Step 6: Rebuild and Test All Pages

1. Rebuild: `python build.py {sitename}`
2. Start server: `python serve.py {sitename} 8004`
3. Test every page with screenshots
4. Validate all pages match quality standards

### Step 7: Iterate Until Perfect

If issues remain:

1. Document specific remaining problems
2. Update CSS or HTML targeting specific issues
3. Rebuild and test again
4. Repeat until perfect

### Step 8: Deploy to GitHub Pages

```bash
rsync -av --exclude='.git' \
  publicsites/{sitename}.github.io/ \
  publicsites/{github-repo}.github.io/

cd publicsites/{github-repo}.github.io
git add -A
git commit -m "Professional design optimization"
git push
```

## Common Design Issues and Solutions

See `references/common-design-issues.md` for:

- Header text breaking into multiple lines → Solution
- Text aligned left with excessive empty space → Solution
- Banner not full-width → Solution
- Navigation vertical instead of horizontal → Solution
- Inconsistent spacing → Solution

## Professional Design Patterns

See `references/professional-patterns.md` for proven patterns:

- Compact horizontal headers
- Separated navigation bars
- Full-width hero banners
- White content containers with shadow
- Professional color palettes by sector

## Best Practices

### Do:

✅ Always compare with reference when replicating a design
✅ Take screenshots at each iteration
✅ Test all pages, not just homepage
✅ Use ui-ux-designer agent for complex CSS
✅ Iterate until perfect
✅ Follow CSS cascade order
✅ Verify on live site after deployment

### Don't:

❌ Modify CSS order
❌ Add inline styles
❌ Skip testing other pages
❌ Deploy without local testing
❌ Forget to rebuild after changes
❌ Rush the iteration

## Real-World Example: Carbonellestrany Site

### Problem
- Header text breaking into multiple lines
- Content left-aligned with excessive empty space
- No horizontal navigation
- Small centered banner instead of full-width
- Poor spacing and unprofessional layout

### Solution Applied
1. UI/UX Designer agent with medical professional design specs
2. CSS redesign (4 files: variables, main, components, reset)
3. HTML structure fix (moved banner outside container)
4. Tested all 6 pages
5. Iterated for perfect spacing and alignment
6. Deployed to GitHub Pages

### Result
✅ Professional medical website matching original quality
✅ Compact header with single horizontal line
✅ Dark blue navigation bar
✅ Full-width hero banner
✅ White content containers with shadows
✅ Professional medical color palette
✅ Consistent spacing across all pages

**Time**: ~2 hours including analysis, design, testing, iteration, deployment

## Resources

- `references/boilerplate-architecture.md` - Complete system architecture
- `references/css-organization.md` - CSS file organization
- `references/common-design-issues.md` - Issue catalog with solutions
- `references/professional-patterns.md` - Proven design patterns
- `references/optimization-workflow.md` - Detailed workflow checklist
- `scripts/analyze-css.py` - Automated CSS quality checks
- `scripts/validate-structure.py` - HTML/CSS structure validation
