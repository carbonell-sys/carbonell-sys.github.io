# Common Design Issues and Solutions

This reference catalog documents frequent design problems encountered in boilerplate sites and their proven solutions.

## Issue 1: Header Text Breaking into Multiple Lines

### Problem
Logo text like "Dr. Xavier Carbonell-Estrany - Medicina Perinatal" appears on multiple lines instead of one horizontal line.

### Symptoms
- Text wraps vertically
- Logo and text not aligned horizontally
- Header takes excessive vertical space
- Looks unprofessional on mobile and desktop

### Root Cause
- Insufficient container width
- Text not using flexbox/inline layout
- Missing `white-space: nowrap` or flex properties

### Solution

**main.css:**
```css
.header-logo {
  display: flex;
  align-items: center;
  gap: var(--space-sm);
  white-space: nowrap;  /* Prevent text wrapping */
}

.header-logo img {
  width: 40px;
  flex-shrink: 0;  /* Prevent logo from shrinking */
}

.header-logo-text {
  font-size: var(--font-size-lg);
  font-weight: var(--font-weight-semibold);
}
```

**HTML structure (templates/components/header.html):**
```html
<a href="/{{ lang }}/" class="header-logo">
  <img src="/assets/images/logo.png" alt="Logo">
  <span class="header-logo-text">Site Name</span>
</a>
```

---

## Issue 2: Text Aligned Left with Excessive Empty Space on Right

### Problem
Content text is pushed to the far left with large empty white space on the right side.

### Symptoms
- Unbalanced page layout
- Excessive whitespace on one side
- Poor use of screen real estate
- Appears broken or incomplete

### Root Cause
- Missing container centering
- Incorrect max-width on content
- No horizontal centering applied
- Content not wrapped properly

### Solution

**main.css:**
```css
.container {
  width: 100%;
  max-width: var(--container-xl);  /* e.g., 1200px */
  margin-left: auto;  /* Center horizontally */
  margin-right: auto;
  padding-left: var(--space-lg);
  padding-right: var(--space-lg);
}

.section-white {
  background: white;
  max-width: 1000px;
  margin: 0 auto var(--space-xl);  /* Center with bottom margin */
  padding: var(--space-2xl);
  box-shadow: var(--shadow-md);
}
```

**HTML structure:**
```html
<main>
  <div class="container">
    <div class="section-white">
      <!-- Content here will be centered -->
    </div>
  </div>
</main>
```

---

## Issue 3: Banner Not Full-Width

### Problem
Hero banner image is constrained by container and doesn't span full viewport width.

### Symptoms
- Banner has margins on left/right
- Doesn't extend to screen edges
- Looks small and unprofessional
- White gaps on sides

### Root Cause
- Image inside `.container` class
- Container has max-width and padding
- Image inherits container constraints

### Solution

**HTML - Move image OUTSIDE container:**
```html
<!-- BEFORE (wrong) -->
<section class="hero">
  <div class="container">
    <img src="/assets/images/banner.jpg" class="w-full">
    <h1>Title</h1>
  </div>
</section>

<!-- AFTER (correct) -->
<section class="hero">
  <img src="/assets/images/banner.jpg" class="hero-banner">
  <div class="container">
    <h1>Title</h1>
    <!-- rest of content -->
  </div>
</section>
```

**CSS - Style full-width banner:**
```css
.hero-banner {
  width: 100%;
  height: auto;
  display: block;
  margin-bottom: var(--space-xl);
}

.hero {
  margin-bottom: var(--space-3xl);
}
```

---

## Issue 4: Navigation Vertical Instead of Horizontal

### Problem
Navigation menu items stack vertically instead of spreading horizontally.

### Symptoms
- Menu items in column
- Takes excessive vertical space
- Not professional desktop experience
- Poor use of screen width

### Root Cause
- Missing flexbox on nav container
- List items display as block
- No horizontal layout applied

### Solution

**main.css:**
```css
.nav {
  background: var(--color-primary);
}

.nav-list {
  display: flex;  /* Horizontal layout */
  list-style: none;
  margin: 0;
  padding: 0;
  gap: var(--space-md);
}

.nav-item {
  margin: 0;
}

.nav-link {
  display: block;
  padding: var(--space-md) var(--space-lg);
  color: white;
  text-transform: uppercase;
}

/* Mobile: vertical stack */
@media (max-width: 768px) {
  .nav-list {
    flex-direction: column;
    gap: 0;
  }
}
```

---

## Issue 5: Inconsistent Spacing

### Problem
Margins, padding, and gaps are inconsistent across the site.

### Symptoms
- Some sections too cramped
- Others have excessive space
- No rhythm or visual harmony
- Looks amateur

### Root Cause
- Hard-coded pixel values
- Not using spacing system
- Each element styled independently

### Solution

**Use spacing tokens from variables.css:**
```css
/* variables.css - Define once */
:root {
  --space-xs: 0.25rem;   /* 4px */
  --space-sm: 0.5rem;    /* 8px */
  --space-md: 1rem;      /* 16px */
  --space-lg: 1.5rem;    /* 24px */
  --space-xl: 2rem;      /* 32px */
  --space-2xl: 3rem;     /* 48px */
  --space-3xl: 4rem;     /* 64px */
  --space-4xl: 6rem;     /* 96px */
}
```

**Apply consistently everywhere:**
```css
.section {
  padding: var(--space-3xl) 0;  /* Not 50px */
}

.card {
  padding: var(--space-2xl);  /* Not 40px */
  margin-bottom: var(--space-xl);  /* Not 35px */
}
```

**Utility classes (components.css):**
```css
.mb-lg { margin-bottom: var(--space-lg); }
.mt-xl { margin-top: var(--space-xl); }
.gap-md { gap: var(--space-md); }
```

---

## Issue 6: Non-Professional Colors

### Problem
Colors don't match professional standards for the sector (medical, tech, finance).

### Symptoms
- Bright, garish colors
- Poor contrast
- Doesn't convey trust/authority
- Inappropriate for industry

### Root Cause
- Default boilerplate colors used
- No sector-appropriate palette
- Random color choices

### Solution

**Define professional palette per sector:**

**Medical (e.g., carbonellestrany):**
```css
:root {
  --color-primary: #1B3A6B;   /* Deep Navy - trust, authority */
  --color-secondary: #00748E;  /* Medical Teal - clinical */
  --color-accent: #B8860B;     /* Prestige Gold - awards */
}
```

**Technology:**
```css
:root {
  --color-primary: #2563EB;   /* Vibrant Blue - innovation */
  --color-secondary: #7C3AED;  /* Purple - creativity */
  --color-accent: #10B981;     /* Green - growth */
}
```

**Finance:**
```css
:root {
  --color-primary: #1E3A5F;   /* Navy - stability */
  --color-secondary: #C19A6B;  /* Gold - wealth */
  --color-accent: #2C5F2D;     /* Forest Green - prosperity */
}
```

**Law/Legal:**
```css
:root {
  --color-primary: #1F2937;   /* Charcoal - seriousness */
  --color-secondary: #8B4513;  /* Wood Brown - tradition */
  --color-accent: #B8860B;     /* Gold - prestige */
}
```

---

## Issue 7: Poor Mobile Responsiveness

### Problem
Layout breaks or looks poor on mobile devices.

### Symptoms
- Horizontal scrolling
- Text too small/large
- Touch targets too small
- Grid doesn't adapt

### Root Cause
- Fixed widths instead of responsive
- Missing media queries
- Not mobile-first approach

### Solution

**Mobile-first CSS approach:**
```css
/* Base (mobile) styles */
.header-logo {
  font-size: var(--font-size-base);
}

.nav-list {
  flex-direction: column;
}

.grid-3 {
  grid-template-columns: 1fr;  /* Single column mobile */
}

/* Tablet and up */
@media (min-width: 768px) {
  .header-logo {
    font-size: var(--font-size-lg);
  }

  .nav-list {
    flex-direction: row;
  }

  .grid-3 {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

**Use responsive utilities:**
```css
.container {
  width: 100%;
  padding-left: var(--space-md);  /* Mobile padding */
  padding-right: var(--space-md);
}

@media (min-width: 768px) {
  .container {
    padding-left: var(--space-lg);
    padding-right: var(--space-lg);
  }
}
```

---

## Issue 8: Poor Typography Hierarchy

### Problem
All text looks same size/weight, no clear hierarchy.

### Symptoms
- Headings not prominent
- Body text same as headings
- Difficult to scan
- Looks monotonous

### Root Cause
- Not using proper heading tags
- Font sizes too similar
- Missing font-weight variation

### Solution

**Define clear scale (reset.css):**
```css
h1 {
  font-size: var(--font-size-4xl);  /* 36px */
  font-weight: var(--font-weight-bold);
  line-height: var(--line-height-tight);
  margin-bottom: var(--space-lg);
}

h2 {
  font-size: var(--font-size-3xl);  /* 30px */
  font-weight: var(--font-weight-bold);
}

h3 {
  font-size: var(--font-size-2xl);  /* 24px */
  font-weight: var(--font-weight-semibold);
}

p {
  font-size: var(--font-size-base);  /* 16px */
  line-height: var(--line-height-relaxed);
  margin-bottom: var(--space-md);
}

.text-lg {
  font-size: var(--font-size-lg);  /* 18px - important paragraphs */
}
```

---

## Issue 9: Cards Without Visual Hierarchy

### Problem
Cards are flat, no depth, blend into background.

### Symptoms
- No shadow or elevation
- Hard to distinguish sections
- Looks flat and boring
- Poor visual interest

### Root Cause
- Missing box-shadow
- No hover effects
- No border or elevation cues

### Solution

**Enhanced card component (components.css):**
```css
.card {
  background: white;
  border-radius: var(--radius-lg);
  padding: var(--space-2xl);
  box-shadow: var(--shadow-md);
  transition: all var(--transition-normal);
  border-left: 4px solid transparent;
}

.card:hover {
  transform: translateY(-4px);
  box-shadow: var(--shadow-xl);
  border-left-color: var(--color-primary);
}

.card-header {
  margin-bottom: var(--space-lg);
  padding-bottom: var(--space-md);
  border-bottom: 2px solid var(--color-bg-alt);
}

.card-title {
  font-size: var(--font-size-2xl);
  color: var(--color-primary);
  margin-bottom: var(--space-sm);
}
```

---

## Issue 10: Inline Styles in HTML

### Problem
HTML content files contain `style=""` attributes.

### Symptoms
- Can't update styles globally
- CSS not centralized
- Hard to maintain
- Breaks boilerplate principles

### Root Cause
- Not using utility classes
- Direct styling in content
- Misunderstanding of system

### Solution

**NEVER use inline styles:**
```html
<!-- ❌ WRONG -->
<div style="margin-bottom: 2rem; text-align: center;">
  <h1 style="color: #1B3A6B;">Title</h1>
</div>

<!-- ✅ CORRECT -->
<div class="mb-2xl text-center">
  <h1 class="text-primary">Title</h1>
</div>
```

**Use utility classes from components.css:**
- Spacing: `.mt-lg`, `.mb-xl`, `.gap-md`
- Typography: `.text-center`, `.text-primary`, `.text-bold`
- Layout: `.flex`, `.justify-between`, `.w-full`

---

## Debugging Checklist

When encountering design issues:

1. **Take screenshots** of current vs desired state
2. **Identify which file** needs modification (variables, main, components)
3. **Check cascade order** - variables loaded first?
4. **Inspect with DevTools** - what styles are applied?
5. **Test on all pages** - is issue site-wide or page-specific?
6. **Validate HTML structure** - proper nesting?
7. **Rebuild after changes** - `python build.py {sitename}`
8. **Test responsive** - all breakpoints
9. **Compare with reference** - match professional standard
10. **Iterate until perfect** - don't settle for "good enough"

## Getting Help

If stuck on a design issue:

1. **Document the problem** with screenshots
2. **Identify desired outcome** with reference
3. **List what you've tried** already
4. **Use ui-ux-designer agent** with detailed requirements
5. **Test the solution** thoroughly before deploying
