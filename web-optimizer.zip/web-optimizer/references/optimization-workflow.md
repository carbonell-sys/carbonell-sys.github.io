# Optimization Workflow Checklist

Detailed step-by-step checklist for optimizing website designs.

## Pre-Flight Checklist

Before starting optimization:

- [ ] Site is in `sites/{sitename}/src/` directory
- [ ] Build system works: `python build.py {sitename}`
- [ ] Local preview works: `python serve.py {sitename}`
- [ ] Have reference design (original site or mockup)
- [ ] Screenshots of current state captured
- [ ] Git repository is up to date

## Step 1: Analysis Checklist

### Capture Current State

- [ ] Navigate to site (local or live)
- [ ] Take full-page screenshot of homepage
- [ ] Take screenshots of 3-5 key pages (about, contact, services)
- [ ] Note viewport size used for screenshots
- [ ] Document browser/device used

### Capture Reference Design

- [ ] Navigate to reference site
- [ ] Take full-page screenshots of equivalent pages
- [ ] Note specific design elements to replicate
- [ ] Identify color palette used
- [ ] Note typography choices
- [ ] Document spacing patterns

### Commands

```bash
# Start local server
python serve.py {sitename} 8004

# In Claude, use Playwright:
# mcp__playwright__browser_navigate: http://localhost:8004/{lang}/
# mcp__playwright__browser_take_screenshot: fullPage: true
```

## Step 2: Comparison Checklist

### Header Analysis

- [ ] Logo placement and size
- [ ] Text layout (single line vs multiple)
- [ ] Navigation structure (separate bar vs in header)
- [ ] Search box presence and position
- [ ] Language selector presence and position
- [ ] Background color
- [ ] Height/padding
- [ ] Sticky/fixed behavior

### Navigation Analysis

- [ ] Layout (horizontal vs vertical)
- [ ] Background color
- [ ] Text color and size
- [ ] Hover state styling
- [ ] Active page indication
- [ ] Mobile behavior (hamburger menu?)
- [ ] Number of items
- [ ] Spacing between items

### Hero/Banner Analysis

- [ ] Full-width vs contained
- [ ] Image dimensions (height)
- [ ] Overlay text present?
- [ ] Call-to-action buttons?
- [ ] Background treatment
- [ ] Spacing above/below

### Content Layout Analysis

- [ ] Container max-width
- [ ] Centering approach
- [ ] Background color
- [ ] Card/section styling
- [ ] Shadow usage
- [ ] Border radius
- [ ] Padding inside containers

### Typography Analysis

- [ ] Font families (serif/sans)
- [ ] H1 size and weight
- [ ] H2, H3 sizes
- [ ] Body text size
- [ ] Line height
- [ ] Text color
- [ ] Hierarchy clarity

### Color Analysis

- [ ] Primary color (hex code)
- [ ] Secondary color
- [ ] Accent color
- [ ] Text color
- [ ] Background color
- [ ] Alt background color
- [ ] Link color

### Spacing Analysis

- [ ] Section vertical padding
- [ ] Container horizontal padding
- [ ] Card padding
- [ ] Gaps in grids
- [ ] Margins between elements
- [ ] Consistency across pages

## Step 3: Issue Identification Checklist

### Header & Navigation Issues

- [ ] Text breaking into multiple lines?
- [ ] Logo not aligned with text?
- [ ] Navigation not horizontal?
- [ ] Missing navigation bar?
- [ ] Poor mobile responsiveness?
- [ ] Active page not indicated?

### Hero/Banner Issues

- [ ] Banner not full-width?
- [ ] Image low quality or pixelated?
- [ ] Wrong dimensions (too tall/short)?
- [ ] Missing overlay text?
- [ ] Constrained by container?

### Content Layout Issues

- [ ] Text aligned left with empty space right?
- [ ] No max-width on containers?
- [ ] Content not centered?
- [ ] Missing white background containers?
- [ ] No shadow/depth on cards?
- [ ] Inconsistent spacing?

### Typography Issues

- [ ] Hierarchy not clear?
- [ ] Sizes too similar?
- [ ] Font not professional?
- [ ] Line height too tight?
- [ ] Color too light/dark?

### Color Issues

- [ ] Not appropriate for sector?
- [ ] Poor contrast?
- [ ] Too bright/garish?
- [ ] Inconsistent usage?

### Spacing Issues

- [ ] Cramped sections?
- [ ] Excessive whitespace?
- [ ] Inconsistent rhythm?
- [ ] Not using spacing system?

### Mobile Issues

- [ ] Horizontal scrolling?
- [ ] Text too small?
- [ ] Touch targets too small?
- [ ] Layout breaks?
- [ ] Images overflow?

## Step 4: UI/UX Designer Agent Prompt Template

```markdown
Use Task tool with subagent_type: "ui-ux-designer"

I need you to completely redesign the CSS for the {sitename} site to match the professional design at {reference-url}.

**CRITICAL DESIGN REQUIREMENTS** (based on original site screenshots):

**1. HEADER LAYOUT:**
- Logo icon + "{exact text}" text must be in ONE horizontal line
- Logo should be ~{size}px, text next to it (not below)
- Background: {color}
- Height: {height}px
- Top-right: {search box? language selector?}
- Sticky positioning: {yes/no}

**2. NAVIGATION BAR:**
- Separate horizontal bar below header
- Background: {color hex}
- Items: {list exact menu items}
- Text: white, uppercase, {size}px
- Spacing: items spread horizontally with {gap}px gap
- Hover: {describe hover effect}
- Active state: {describe active indication}

**3. HERO BANNER:**
- Full-width banner image
- Should span 100% of viewport width
- Height: ~{height}px
- Image: /assets/images/{filename}
- Overlay text: {yes/no, where positioned}

**4. CONTENT LAYOUT:**
- White background container
- Max-width: ~{width}px, centered
- Padding: {padding}px
- Shadow: {describe shadow}
- Border-radius: {radius}px
- Margin between sections: {spacing}

**5. TYPOGRAPHY:**
- Headings: {serif/sans}, {color}, {weight}
- H1: {size}px
- H2: {size}px
- H3: {size}px
- Body text: {color}, {size}px
- Line height: {value}
- Font families: {exact fonts}

**6. SPACING:**
- Section padding: {value}
- Card padding: {value}
- Between elements: {value}
- Grid gaps: {value}
- No excessive empty space
- Content feels balanced and centered

**7. COLORS:**
- Primary: {hex}
- Secondary: {hex}
- Accent: {hex}
- Text: {hex}
- Background: {hex}
- Alt background: {hex}

**CURRENT PROBLEMS TO FIX:**
❌ {List each specific issue from Step 3}
❌
❌
❌

**FILES TO MODIFY:**
You need to update these CSS files in sites/{sitename}/src/static/css/:
- variables.css (colors, spacing, typography tokens)
- main.css (layout, header, navigation, hero sections)
- components.css (containers, cards, navigation components, utilities)
- reset.css (if needed for typography baseline)

**TEMPLATE STRUCTURE** (don't modify templates, just ensure CSS works):
- Header is in src/templates/components/header.html
- Content injected via {{ content | safe }}
- Navigation uses .nav, .nav-list, .nav-item classes

**EXPECTED RESULT:**
✅ {List each desired outcome}
✅
✅
✅

Return the complete updated CSS files.
```

## Step 5: HTML Structure Fixes Checklist

### Banner Full-Width Fix

- [ ] Read current index.html
- [ ] Identify banner image inside container
- [ ] Move `<img>` tag outside `.container`
- [ ] Add class `.hero-banner` to image
- [ ] Update CSS in main.css for `.hero-banner`
- [ ] Test on other pages if they have banners

### Header Restructure (if needed)

- [ ] Read templates/components/header.html
- [ ] Separate header and navigation into two sections
- [ ] Update CSS classes accordingly
- [ ] Test on all pages

### Commands

```bash
# Read current structure
# Use Read tool on: sites/{sitename}/src/content/{lang}/index.html

# Edit with specific old_string and new_string
# Use Edit tool with exact matches

# Rebuild to test
python build.py {sitename}
```

## Step 6: Build and Test Checklist

### Build

- [ ] Run build command: `python build.py {sitename}`
- [ ] Check for errors in output
- [ ] Verify CSS minified correctly
- [ ] Verify all pages built
- [ ] Check output directory size reasonable

### Start Server

- [ ] Start server: `python serve.py {sitename} 8004`
- [ ] Verify server started successfully
- [ ] Note port number

### Test Each Page

For each page (index, about, contact, services, etc.):

- [ ] Navigate: `http://localhost:8004/{lang}/{page}/`
- [ ] Take full-page screenshot
- [ ] Compare with reference design
- [ ] Check header consistent
- [ ] Check navigation works
- [ ] Check active page highlighted
- [ ] Check spacing consistent
- [ ] Check colors match
- [ ] Check typography hierarchy
- [ ] Note any remaining issues

### Commands

```bash
# Rebuild
python build.py {sitename}

# Start server
python serve.py {sitename} 8004

# In Claude, navigate and screenshot each page:
# mcp__playwright__browser_navigate: http://localhost:8004/es/
# mcp__playwright__browser_take_screenshot: fullPage: true, filename: "{page}-test.png"
```

## Step 7: Iteration Checklist

### Document Remaining Issues

For each issue:
- [ ] Page name
- [ ] Specific problem description
- [ ] Expected behavior/appearance
- [ ] Priority (critical/important/nice-to-have)

### Apply Fixes

- [ ] Read relevant CSS file
- [ ] Make targeted change
- [ ] Document what was changed
- [ ] Rebuild: `python build.py {sitename}`
- [ ] Test affected pages
- [ ] Take new screenshots
- [ ] Compare before/after

### Iteration Loop

- [ ] Are there any remaining issues?
- [ ] If yes, go back to "Document Remaining Issues"
- [ ] If no, proceed to Step 8

### Quality Standards

Site is ready when:
- [ ] All pages match reference quality
- [ ] No layout breaks on any page
- [ ] Typography hierarchy clear
- [ ] Colors appropriate and consistent
- [ ] Spacing balanced throughout
- [ ] Mobile responsive (test at 375px, 768px, 1024px)
- [ ] No inline styles in HTML
- [ ] CSS follows boilerplate architecture

## Step 8: Deployment Checklist

### Pre-Deployment

- [ ] All pages tested and perfect
- [ ] Build completed successfully
- [ ] No errors or warnings
- [ ] Screenshots document improvements
- [ ] Git repo is up to date

### Copy to GitHub Repo

```bash
# Sync files (excluding .git)
rsync -av --exclude='.git' \
  publicsites/{sitename}.github.io/ \
  publicsites/{github-repo}.github.io/
```

- [ ] Command completed successfully
- [ ] Check file count transferred
- [ ] No errors in rsync output

### Git Commit

```bash
cd publicsites/{github-repo}.github.io
git add -A
git status
```

- [ ] Review changes in git status
- [ ] Verify only expected files changed
- [ ] Check for any unexpected deletions
- [ ] CSS and HTML files show changes

### Git Push

```bash
git commit -m "Professional design optimization: [describe key changes]"
git push
```

- [ ] Commit successful
- [ ] Push successful
- [ ] No conflicts or errors

### Verify Deployment

- [ ] Wait 1-2 minutes for GitHub Pages rebuild
- [ ] Visit live URL: `https://{username}.github.io/`
- [ ] Test homepage
- [ ] Test 3-5 key pages
- [ ] Hard refresh (Cmd+Shift+R / Ctrl+Shift+R)
- [ ] Check in different browsers (Chrome, Firefox, Safari)
- [ ] Check on mobile device if possible

### Post-Deployment

- [ ] Site looks correct on live URL
- [ ] All pages accessible
- [ ] Navigation works
- [ ] Images load correctly
- [ ] CSS applied correctly
- [ ] No console errors (open DevTools)

### Rollback Plan (if needed)

If deployment has issues:

```bash
cd publicsites/{github-repo}.github.io
git log  # Find previous commit hash
git revert {commit-hash}
git push
```

## Time Estimates

- **Step 1 (Analysis)**: 15-30 minutes
- **Step 2 (Comparison)**: 20-30 minutes
- **Step 3 (Issue Identification)**: 10-15 minutes
- **Step 4 (UI/UX Agent)**: 20-40 minutes (agent work time)
- **Step 5 (HTML Fixes)**: 10-20 minutes
- **Step 6 (Build & Test)**: 20-30 minutes
- **Step 7 (Iteration)**: 30-60 minutes (varies by issues)
- **Step 8 (Deployment)**: 10-15 minutes

**Total**: 2-4 hours for complete optimization

## Success Metrics

Optimization is successful when:

✅ **Visual Comparison**: Side-by-side screenshots show equivalent quality to reference
✅ **All Pages Consistent**: Every page follows same design system
✅ **Professional Appearance**: Looks polished and sector-appropriate
✅ **Responsive**: Works well on mobile, tablet, desktop
✅ **No Technical Issues**: No broken layouts, missing images, CSS errors
✅ **Maintainable**: Uses boilerplate architecture correctly, no inline styles
✅ **User Feedback**: If available, positive response from stakeholders
