# Professional Design Patterns

Proven design patterns for professional websites by sector.

## Header Patterns

### Pattern 1: Compact Horizontal Header
**Use for**: Professional services, medical, legal, academic

```css
.header {
  background: white;
  height: 60px;
  border-bottom: 1px solid #e5e7eb;
}

.header-logo {
  display: flex;
  align-items: center;
  gap: 12px;
  white-space: nowrap;
}

.header-logo img {
  width: 40px;
  height: auto;
}

.header-logo-text {
  font-size: 1.125rem;
  font-weight: 600;
}
```

### Pattern 2: Separated Navigation Bar
**Use for**: Sites needing clear menu structure

```css
.nav {
  background: var(--color-primary);
  border-bottom: 3px solid var(--color-secondary);
}

.nav-list {
  display: flex;
  gap: 1rem;
}

.nav-link {
  padding: 1rem 1.5rem;
  color: white;
  text-transform: uppercase;
  font-size: 0.875rem;
}
```

## Hero Banner Patterns

### Pattern 1: Full-Width Image with Overlay
```css
.hero {
  position: relative;
}

.hero-banner {
  width: 100%;
  height: 400px;
  object-fit: cover;
}

.hero-overlay {
  position: absolute;
  top: 50%;
  right: 5%;
  transform: translateY(-50%);
  background: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 2rem;
}
```

### Pattern 2: Centered Content Hero
```css
.hero {
  background: linear-gradient(135deg, var(--color-primary), var(--color-secondary));
  padding: 6rem 0;
  text-align: center;
  color: white;
}
```

## Content Container Patterns

### Pattern 1: White Card Container
**Use for**: Professional content sections

```css
.section-white {
  background: white;
  max-width: 1000px;
  margin: 0 auto 2rem;
  padding: 3rem;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  border-radius: 0.5rem;
}
```

### Pattern 2: Alternating Sections
```css
.section:nth-child(odd) {
  background: white;
}

.section:nth-child(even) {
  background: var(--color-bg-alt);
}
```

## Professional Color Palettes

### Medical / Healthcare
```css
:root {
  --color-primary: #1B3A6B;    /* Navy - trust */
  --color-secondary: #00748E;   /* Teal - clinical */
  --color-accent: #B8860B;      /* Gold - prestige */
  --color-text: #2D3748;
  --color-bg-alt: #F0F4F8;
}
```

### Technology / SaaS
```css
:root {
  --color-primary: #2563EB;    /* Blue - innovation */
  --color-secondary: #7C3AED;   /* Purple - creativity */
  --color-accent: #10B981;      /* Green - growth */
  --color-text: #1F2937;
  --color-bg-alt: #F9FAFB;
}
```

### Finance / Banking
```css
:root {
  --color-primary: #1E3A5F;    /* Navy - stability */
  --color-secondary: #C19A6B;   /* Gold - wealth */
  --color-accent: #2C5F2D;      /* Green - prosperity */
  --color-text: #212529;
  --color-bg-alt: #F8F9FA;
}
```

### Legal / Law
```css
:root {
  --color-primary: #1F2937;    /* Charcoal - seriousness */
  --color-secondary: #8B4513;   /* Brown - tradition */
  --color-accent: #B8860B;      /* Gold - prestige */
  --color-text: #111827;
  --color-bg-alt: #F3F4F6;
}
```

### Creative / Design
```css
:root {
  --color-primary: #6366F1;    /* Indigo - creativity */
  --color-secondary: #EC4899;   /* Pink - energy */
  --color-accent: #F59E0B;      /* Amber - warmth */
  --color-text: #18181B;
  --color-bg-alt: #FAFAFA;
}
```

## Card Design Patterns

### Pattern 1: Elevated Cards with Hover
```css
.card {
  background: white;
  padding: 2rem;
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  border-left: 4px solid transparent;
}

.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
  border-left-color: var(--color-primary);
}
```

### Pattern 2: Bordered Cards
```css
.card {
  background: white;
  padding: 2rem;
  border: 2px solid #e5e7eb;
  border-radius: 0.5rem;
  transition: border-color 0.2s;
}

.card:hover {
  border-color: var(--color-primary);
}
```

## Typography Patterns

### Pattern 1: Serif Headings + Sans Body
```css
h1, h2, h3, h4, h5, h6 {
  font-family: Georgia, Cambria, 'Times New Roman', serif;
  font-weight: 700;
  color: var(--color-primary);
}

body, p, li {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  line-height: 1.6;
}
```

### Pattern 2: All Sans-Serif Modern
```css
* {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

h1, h2, h3 {
  font-weight: 700;
}

h4, h5, h6 {
  font-weight: 600;
}
```

## Spacing System (8px Grid)

```css
:root {
  --space-xs: 0.25rem;   /* 4px */
  --space-sm: 0.5rem;    /* 8px */
  --space-md: 1rem;      /* 16px */
  --space-lg: 1.5rem;    /* 24px */
  --space-xl: 2rem;      /* 32px */
  --space-2xl: 3rem;     /* 48px */
  --space-3xl: 4rem;     /* 64px */
  --space-4xl: 6rem;     /* 96px */
}
```

**Usage:**
- Section padding: `var(--space-3xl)` or `var(--space-4xl)`
- Card padding: `var(--space-2xl)`
- Between elements: `var(--space-lg)` or `var(--space-xl)`
- Small gaps: `var(--space-md)`

## Button Patterns

### Pattern 1: Primary CTA
```css
.btn-primary {
  background: var(--color-primary);
  color: white;
  padding: 0.75rem 2rem;
  border-radius: 0.375rem;
  font-weight: 600;
  transition: all 0.2s;
}

.btn-primary:hover {
  background: var(--color-secondary);
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}
```

### Pattern 2: Outline Button
```css
.btn-outline {
  background: transparent;
  color: var(--color-primary);
  border: 2px solid var(--color-primary);
  padding: 0.75rem 2rem;
  border-radius: 0.375rem;
}

.btn-outline:hover {
  background: var(--color-primary);
  color: white;
}
```

## Footer Patterns

### Pattern 1: Multi-Column Footer
```css
footer {
  background: var(--color-text);
  color: white;
  padding: 3rem 0 1.5rem;
}

.footer-content {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  margin-bottom: 2rem;
}

.footer-bottom {
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  padding-top: 1.5rem;
  text-align: center;
}
```

## Professional Website Checklist

✅ **Header**:
- Logo + text in horizontal line
- Clean, minimal design
- Sticky or fixed positioning
- Consistent across pages

✅ **Navigation**:
- Horizontal bar on desktop
- Clear active state
- Responsive mobile menu
- Logical hierarchy

✅ **Hero/Banner**:
- Full-width or contained as appropriate
- High-quality images
- Clear messaging
- Appropriate height (300-500px)

✅ **Content**:
- Max-width containers (1000-1200px)
- Centered on page
- White or subtle background
- Good spacing rhythm

✅ **Typography**:
- Clear hierarchy (h1 > h2 > h3 > p)
- Readable sizes (16px+ for body)
- Appropriate line-height (1.5-1.8)
- Professional fonts

✅ **Colors**:
- Sector-appropriate palette
- Sufficient contrast (WCAG AA)
- Consistent use across site
- Professional, not garish

✅ **Spacing**:
- Consistent 8px grid system
- Balanced whitespace
- No cramped sections
- Breathing room

✅ **Cards/Components**:
- Subtle shadows for depth
- Rounded corners (4-8px)
- Hover effects for interactivity
- Consistent styling

✅ **Responsive**:
- Mobile-first approach
- Breakpoints at 768px, 1024px
- Touch-friendly targets (44px+)
- No horizontal scrolling

✅ **Performance**:
- Optimized images
- Minified CSS/JS
- Lazy loading where appropriate
- Fast page load (<3s)
