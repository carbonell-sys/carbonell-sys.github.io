# Boilerplate Architecture Reference

## Overview

The Python+Jinja2 static site generator boilerplate is a mono-repo multi-site system designed to manage multiple independent static websites from one private repository.

## Repository Structure

```
web_boilerplate/ (private repo)
├── sites/                          # Source code for all sites
│   ├── _boilerplate/               # Template for new sites
│   ├── swimanalytics/
│   │   └── src/
│   ├── carbonellestrany/
│   │   └── src/
│   └── site3/
│       └── src/
├── publicsites/ (gitignored)       # Local clones of public GitHub Pages repos
│   ├── swimanalytics.github.io/   # Git clone of public repo
│   ├── carbonell-sys.github.io/
│   └── site3.github.io/
├── build.py                        # Multi-site build script
├── serve.py                        # Local preview server
├── deploy.sh                       # Deploy helper script
├── requirements.txt                # Python dependencies
└── CLAUDE.md                       # Project documentation
```

## Site Structure

Each site in `sites/{sitename}/src/` follows this architecture:

```
sites/{sitename}/src/
├── content/                     # Page content by language
│   ├── ca/                     # Catalan content
│   │   ├── index.html
│   │   ├── about.html
│   │   └── contact.html
│   └── en/                     # English content
│       ├── index.html
│       ├── about.html
│       └── contact.html
├── templates/                   # Jinja2 templates
│   ├── base.html               # Main layout template
│   └── components/             # Reusable components
│       ├── header.html         # Logo, nav, language selector
│       ├── footer.html         # Footer with links
│       └── cookie-banner.html  # GDPR cookie consent
├── static/                     # Static assets
│   ├── css/
│   │   ├── variables.css       # Design tokens (colors, spacing, fonts)
│   │   ├── reset.css           # Modern CSS reset + typography
│   │   ├── main.css            # Layout & structure
│   │   ├── components.css      # Components + utility classes
│   │   └── print.css           # Print-specific styles
│   ├── js/
│   │   ├── main.js             # Menu, forms, language switch
│   │   ├── cookie-consent.js   # GDPR banner logic
│   │   ├── lazy-load.js        # Image lazy loading
│   │   └── analytics.js        # GA4 integration
│   └── images/                 # Images and icons
│       ├── logo.png
│       ├── logo-dark.png
│       └── icons/
│           ├── favicon-32x32.png
│           ├── favicon-16x16.png
│           └── apple-touch-icon.png
└── data/                       # Configuration files
    ├── config.json             # Site metadata, languages, analytics
    ├── ui-strings.json         # UI translations (nav labels, buttons)
    ├── navigation.json         # Menu structure (id, slug, order)
    └── page-metadata.json      # SEO metadata (title, description, keywords)
```

## Build System

### build.py

Multi-site build script that accepts site name as CLI argument:

```bash
python build.py {sitename}
```

**Build process:**

1. **Validate arguments**: Check `sites/{sitename}/src/` exists
2. **Define paths dynamically**:
   - Source: `sites/{sitename}/src/`
   - Output: `publicsites/{sitename}.github.io/`
3. **Load configurations**: config.json, ui-strings.json, navigation.json, page-metadata.json
4. **For each language**:
   - Read all `.html` files from `src/content/{lang}/`
   - Inject content into `src/templates/base.html`
   - Render with Jinja2 context: lang, ui, nav, site config, page metadata
   - Output to `publicsites/{sitename}.github.io/{lang}/{page}/index.html`
5. **Minify assets**:
   - **CSS**: Concatenate in order (variables → reset → main → components → print), then minify
   - **JS**: Minify each file separately
6. **Copy images** to output `assets/images/`
7. **Generate meta files**: sitemap.xml, robots.txt, manifest.json, _headers, root index.html

**Output structure:**

```
publicsites/{sitename}.github.io/
├── index.html                  # Language redirect
├── sitemap.xml
├── robots.txt
├── manifest.json
├── _headers                    # Cloudflare/Netlify headers
├── assets/
│   ├── css/
│   │   └── main.min.css       # Single concatenated & minified CSS
│   ├── js/
│   │   ├── main.min.js
│   │   ├── analytics.min.js
│   │   ├── cookie-consent.min.js
│   │   └── lazy-load.min.js
│   └── images/                # All images copied
└── {lang}/                     # Per-language directories
    ├── index.html
    ├── about/
    │   └── index.html
    └── contact/
        └── index.html
```

### serve.py

Local preview server with clean URL support:

```bash
python serve.py {sitename} [port]
```

Serves from `publicsites/{sitename}.github.io/` with:
- Clean URLs: `/ca/about/` works (mimics GitHub Pages)
- Default port: 8000
- Optional port specification

### deploy.sh

Automated deployment script:

```bash
./deploy.sh {sitename} "Commit message"
```

**What it does:**

1. Runs `python build.py {sitename}`
2. Checks for changes in public repo
3. Stages, commits, pushes to GitHub
4. Shows deployment status and live URL

## Template System

### base.html

Main layout template with structure:

```html
<!DOCTYPE html>
<html lang="{{ lang }}">
<head>
  <!-- SEO meta tags (title, description, keywords from page-metadata.json) -->
  <!-- Open Graph, Twitter Cards -->
  <!-- Hreflang links for multi-language -->
  <!-- Favicon links -->
  <!-- CSS: /assets/css/main.min.css -->
</head>
<body>
  {% include 'components/header.html' %}
  <main id="main-content">
    {{ content | safe }}  <!-- Page content injected here -->
  </main>
  {% include 'components/footer.html' %}
  {% include 'components/cookie-banner.html' %}
  <!-- JS: /assets/js/*.min.js -->
</body>
</html>
```

**Jinja2 context variables:**

- `{{ lang }}`: Current language code (e.g., 'ca', 'en')
- `{{ lang_info }}`: Language metadata (name, locale, dir)
- `{{ site }}`: Site config from config.json
- `{{ ui }}`: UI strings for current language
- `{{ nav }}`: Navigation items
- `{{ content }}`: Page content (HTML from content files)
- `{{ page_name }}`: Current page identifier
- `{{ current_page }}`: Full page metadata
- `{{ languages }}`: All available languages
- `{{ analytics_id }}`: Google Analytics ID
- `{{ year }}`: Current year

### Components

**header.html:**
- Logo with link to homepage
- Main navigation menu
- Language selector (if multiple languages)
- Search box (optional)
- Mobile menu toggle

**footer.html:**
- Site description
- Footer navigation links (per language)
- Copyright notice
- Optional: Privacy policy, Terms of use links

**cookie-banner.html:**
- GDPR cookie consent UI
- Triggers analytics loading after acceptance
- Stores consent in localStorage

## Multi-language System

### Content Architecture

- Each page exists as separate HTML file per language
- Content files contain only `<section>` markup (no `<html>`, `<head>`)
- Templates are language-agnostic, receive content via `{{ content | safe }}`

**Example:**

`src/content/ca/index.html`:
```html
<section class="hero">
  <h1>Benvinguts</h1>
  <p>Contingut en català...</p>
</section>
```

`src/content/en/index.html`:
```html
<section class="hero">
  <h1>Welcome</h1>
  <p>Content in English...</p>
</section>
```

### Configuration Architecture

**config.json:**
```json
{
  "site": {
    "title": "Site Name",
    "description": "Site description",
    "url": "https://sitename.github.io",
    "author": "Author Name",
    "default_language": "en"
  },
  "languages": {
    "en": {"name": "English", "locale": "en_US", "dir": "ltr"},
    "ca": {"name": "Català", "locale": "ca_ES", "dir": "ltr"}
  },
  "analytics": {
    "google_analytics_id": "G-XXXXXXXXXX"
  }
}
```

**ui-strings.json:**
```json
{
  "en": {
    "nav": {
      "home": "Home",
      "about": "About",
      "contact": "Contact"
    },
    "footer": {
      "copyright": "© {year} {site_title}. All rights reserved."
    }
  },
  "ca": {
    "nav": {
      "home": "Inici",
      "about": "Sobre nosaltres",
      "contact": "Contacte"
    },
    "footer": {
      "copyright": "© {year} {site_title}. Tots els drets reservats."
    }
  }
}
```

**navigation.json:**
```json
{
  "main": [
    {"id": "home", "slug": "", "order": 1},
    {"id": "about", "slug": "about", "order": 2},
    {"id": "contact", "slug": "contact", "order": 3}
  ]
}
```

**page-metadata.json:**
```json
{
  "en": {
    "index": {
      "title": "Home - Site Name",
      "description": "Welcome to our website",
      "keywords": ["keyword1", "keyword2"],
      "datePublished": "2025-01-01",
      "dateModified": "2025-01-01"
    }
  },
  "ca": {
    "index": {
      "title": "Inici - Nom del lloc",
      "description": "Benvinguts al nostre lloc web",
      "keywords": ["paraula1", "paraula2"],
      "datePublished": "2025-01-01",
      "dateModified": "2025-01-01"
    }
  }
}
```

### URL Structure

- Homepage: `/{lang}/` (e.g., `/ca/`, `/en/`)
- Pages: `/{lang}/{slug}/` (e.g., `/ca/about/`, `/en/contact/`)
- Root `/` redirects to default language with browser detection

## Deployment Workflow

### Initial Setup (per site)

1. **Create public GitHub Pages repository**:
   - Name: `{username}.github.io` or `{sitename}.github.io`
   - Make public
   - Enable Pages: Settings → Pages → Deploy from branch → main

2. **Clone to local `publicsites/`**:
   ```bash
   cd publicsites
   git clone git@github.com:{username}/{sitename}.github.io.git
   ```

3. **Update site URL** in `sites/{sitename}/src/data/config.json`

### Daily Workflow

**Option 1: Using deploy script (recommended)**
```bash
./deploy.sh {sitename} "Descriptive commit message"
```

**Option 2: Manual**
```bash
python build.py {sitename}
cd publicsites/{sitename}.github.io
git add .
git commit -m "Update content"
git push
```

Site live at `https://{username}.github.io/` within 1-2 minutes.

## Key Constraints

- **No server-side logic**: Static HTML generation only
- **Image paths**: Must be absolute from dist root (`/assets/images/...`)
- **CSS order matters**: Concatenation sequence affects cascade
- **Clean URLs**: Build creates `/page/index.html`, not `/page.html`
- **Language detection**: Root index.html uses JavaScript
- **Cookie consent required**: Analytics won't load without GDPR acceptance
- **No inline styles allowed**: Content files must use utility classes only
