# CSS Organization Reference

## CSS File Structure

The boilerplate uses a specific CSS organization where files are concatenated in a precise order during the build process. This order is **critical** and cannot be changed.

### Concatenation Order

```
1. variables.css    → Design tokens (FIRST - available to all other files)
2. reset.css        → Typography baseline (SECOND - sets defaults)
3. main.css         → Layout & structure (THIRD - builds on reset)
4. components.css   → Components + utilities (FOURTH - uses all above)
5. print.css        → Print-specific styles (LAST - media query)
```

**Output**: Single `dist/assets/css/main.min.css`

## 1. variables.css - Design Tokens

**Purpose**: Define all design tokens (colors, spacing, typography) as CSS custom properties.

**Structure**:

```css
:root {
  /* Colors - Primary Palette */
  --color-primary: #1B3A6B;        /* Main brand color */
  --color-secondary: #00748E;       /* Secondary brand color */
  --color-accent: #B8860B;          /* Accent color */

  /* Colors - Neutral Palette */
  --color-text: #2D3748;            /* Main text color */
  --color-text-secondary: #4A5568;  /* Secondary text */
  --color-text-muted: #718096;      /* Muted text */
  --color-bg: #FFFFFF;              /* Page background */
  --color-bg-alt: #F7FAFC;          /* Alternate background */

  /* Colors - Semantic */
  --color-success: #48BB78;
  --color-warning: #ED8936;
  --color-error: #F56565;
  --color-info: #4299E1;

  /* Spacing - 8px base grid */
  --space-xs: 0.25rem;    /* 4px */
  --space-sm: 0.5rem;     /* 8px */
  --space-md: 1rem;       /* 16px */
  --space-lg: 1.5rem;     /* 24px */
  --space-xl: 2rem;       /* 32px */
  --space-2xl: 3rem;      /* 48px */
  --space-3xl: 4rem;      /* 64px */
  --space-4xl: 6rem;      /* 96px */

  /* Typography - Font Families */
  --font-family-sans: -apple-system, BlinkMacSystemFont, 'Segoe UI',
                      Roboto, 'Helvetica Neue', Arial, sans-serif;
  --font-family-serif: Georgia, Cambria, 'Times New Roman', Times, serif;
  --font-family-mono: 'SFMono-Regular', Consolas, 'Liberation Mono',
                      Menlo, Courier, monospace;

  /* Typography - Font Sizes */
  --font-size-xs: 0.75rem;    /* 12px */
  --font-size-sm: 0.875rem;   /* 14px */
  --font-size-base: 1rem;     /* 16px */
  --font-size-lg: 1.125rem;   /* 18px */
  --font-size-xl: 1.25rem;    /* 20px */
  --font-size-2xl: 1.5rem;    /* 24px */
  --font-size-3xl: 1.875rem;  /* 30px */
  --font-size-4xl: 2.25rem;   /* 36px */

  /* Typography - Font Weights */
  --font-weight-light: 300;
  --font-weight-normal: 400;
  --font-weight-medium: 500;
  --font-weight-semibold: 600;
  --font-weight-bold: 700;

  /* Typography - Line Heights */
  --line-height-tight: 1.25;
  --line-height-normal: 1.5;
  --line-height-relaxed: 1.625;
  --line-height-loose: 2;

  /* Layout - Container Widths */
  --container-sm: 640px;
  --container-md: 768px;
  --container-lg: 1024px;
  --container-xl: 1200px;
  --container-max: 1400px;

  /* Layout - Heights */
  --header-height: 60px;
  --nav-height: 50px;
  --footer-height: auto;

  /* Effects - Shadows */
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
  --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);

  /* Effects - Border Radius */
  --radius-sm: 0.125rem;  /* 2px */
  --radius-md: 0.25rem;   /* 4px */
  --radius-lg: 0.5rem;    /* 8px */
  --radius-xl: 1rem;      /* 16px */
  --radius-full: 9999px;  /* Circular */

  /* Transitions */
  --transition-fast: 150ms ease-in-out;
  --transition-normal: 300ms ease-in-out;
  --transition-slow: 500ms ease-in-out;

  /* Z-index layers */
  --z-dropdown: 1000;
  --z-sticky: 1020;
  --z-fixed: 1030;
  --z-modal-backdrop: 1040;
  --z-modal: 1050;
  --z-popover: 1060;
  --z-tooltip: 1070;
}

/* Dark mode overrides (optional) */
@media (prefers-color-scheme: dark) {
  :root {
    --color-text: #E2E8F0;
    --color-bg: #1A202C;
    --color-bg-alt: #2D3748;
  }
}
```

**Best Practices**:
- Use semantic names (`--color-primary` not `--color-blue`)
- Follow 8px spacing grid for consistency
- Define all tokens before using in other files
- Group related properties together
- Include comments for clarity

## 2. reset.css - Typography Baseline

**Purpose**: Modern CSS reset + typography baseline.

**Structure**:

```css
/* Box sizing border-box for all elements */
*,
*::before,
*::after {
  box-sizing: border-box;
}

/* Remove default margins */
* {
  margin: 0;
  padding: 0;
}

/* Set core body defaults */
body {
  min-height: 100vh;
  font-family: var(--font-family-sans);
  font-size: var(--font-size-base);
  line-height: var(--line-height-normal);
  color: var(--color-text);
  background-color: var(--color-bg);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

/* Typography scale */
h1, h2, h3, h4, h5, h6 {
  margin-top: 0;
  margin-bottom: var(--space-md);
  font-weight: var(--font-weight-bold);
  line-height: var(--line-height-tight);
}

h1 { font-size: var(--font-size-4xl); }
h2 { font-size: var(--font-size-3xl); }
h3 { font-size: var(--font-size-2xl); }
h4 { font-size: var(--font-size-xl); }
h5 { font-size: var(--font-size-lg); }
h6 { font-size: var(--font-size-base); }

/* Paragraph spacing */
p {
  margin-bottom: var(--space-md);
}

/* Lists */
ul, ol {
  margin-bottom: var(--space-md);
  padding-left: var(--space-xl);
}

li {
  margin-bottom: var(--space-xs);
}

/* Links */
a {
  color: var(--color-primary);
  text-decoration: none;
  transition: color var(--transition-fast);
}

a:hover {
  color: var(--color-secondary);
  text-decoration: underline;
}

/* Images */
img, picture, video, canvas, svg {
  display: block;
  max-width: 100%;
  height: auto;
}

/* Form elements */
input, button, textarea, select {
  font: inherit;
}

/* Remove default button styles */
button {
  background: none;
  border: none;
  cursor: pointer;
}

/* Table reset */
table {
  border-collapse: collapse;
  width: 100%;
}

/* Accessibility */
.visually-hidden {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}

/* Skip to main content link */
.skip-link {
  position: absolute;
  top: -40px;
  left: 0;
  background: var(--color-primary);
  color: white;
  padding: var(--space-sm) var(--space-md);
  text-decoration: none;
  z-index: var(--z-tooltip);
}

.skip-link:focus {
  top: 0;
}
```

**Best Practices**:
- Start with modern CSS reset (Josh Comeau or similar)
- Set sensible typography defaults
- Use CSS custom properties from variables.css
- Include accessibility helpers

## 3. main.css - Layout & Structure

**Purpose**: Page layout, header, navigation, hero sections, main structure.

**Structure**:

```css
/* Container */
.container {
  width: 100%;
  max-width: var(--container-xl);
  margin-left: auto;
  margin-right: auto;
  padding-left: var(--space-lg);
  padding-right: var(--space-lg);
}

/* Header */
.header {
  background: white;
  border-bottom: 1px solid var(--color-bg-alt);
  position: sticky;
  top: 0;
  z-index: var(--z-sticky);
}

.header-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: var(--header-height);
  padding: 0 var(--space-lg);
}

.header-logo {
  display: flex;
  align-items: center;
  gap: var(--space-sm);
  font-size: var(--font-size-lg);
  font-weight: var(--font-weight-semibold);
  color: var(--color-text);
}

.header-logo img {
  width: 40px;
  height: auto;
}

/* Navigation */
.nav {
  background: var(--color-primary);
  border-bottom: 3px solid var(--color-secondary);
}

.nav-list {
  display: flex;
  list-style: none;
  margin: 0;
  padding: 0;
  gap: var(--space-md);
}

.nav-item {
  margin: 0;
}

.nav-link {
  display: block;
  padding: var(--space-md) var(--space-lg);
  color: white;
  text-transform: uppercase;
  font-size: var(--font-size-sm);
  font-weight: var(--font-weight-medium);
  transition: background-color var(--transition-fast);
}

.nav-link:hover {
  background-color: rgba(255, 255, 255, 0.1);
  text-decoration: none;
}

.nav-link[aria-current="page"] {
  background-color: rgba(0, 0, 0, 0.2);
  border-bottom: 3px solid white;
}

/* Hero Section */
.hero {
  position: relative;
  margin-bottom: var(--space-3xl);
}

.hero-banner {
  width: 100%;
  height: auto;
  display: block;
}

.hero-content {
  padding: var(--space-3xl) 0;
  text-align: center;
}

/* Main Content */
main {
  min-height: 60vh;
  background: var(--color-bg-alt);
  padding: var(--space-3xl) 0;
}

.section {
  padding: var(--space-3xl) 0;
}

.section-white {
  background: white;
  box-shadow: var(--shadow-md);
  padding: var(--space-2xl);
  margin-bottom: var(--space-xl);
  border-radius: var(--radius-lg);
}

/* Footer */
footer {
  background: var(--color-text);
  color: white;
  padding: var(--space-3xl) 0 var(--space-xl);
  margin-top: var(--space-4xl);
}

.footer-content {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: var(--space-2xl);
  margin-bottom: var(--space-xl);
}

.footer-bottom {
  border-top: 1px solid rgba(255, 255, 255, 0.1);
  padding-top: var(--space-lg);
  text-align: center;
  font-size: var(--font-size-sm);
}

/* Responsive */
@media (max-width: 768px) {
  .header-logo {
    font-size: var(--font-size-base);
  }

  .nav-list {
    flex-direction: column;
    gap: 0;
  }

  .nav-link {
    padding: var(--space-md);
  }

  .container {
    padding-left: var(--space-md);
    padding-right: var(--space-md);
  }
}
```

**Best Practices**:
- Use CSS Grid and Flexbox for layouts
- Sticky header with proper z-index
- Responsive breakpoints
- Semantic section naming

## 4. components.css - Components + Utilities

**Purpose**: Reusable components, cards, buttons, forms, and utility classes.

**Structure**:

```css
/* Buttons */
.btn {
  display: inline-block;
  padding: var(--space-sm) var(--space-lg);
  font-size: var(--font-size-base);
  font-weight: var(--font-weight-medium);
  text-align: center;
  text-decoration: none;
  border-radius: var(--radius-md);
  transition: all var(--transition-fast);
  cursor: pointer;
}

.btn-primary {
  background: var(--color-primary);
  color: white;
}

.btn-primary:hover {
  background: var(--color-secondary);
  text-decoration: none;
}

.btn-large {
  padding: var(--space-md) var(--space-2xl);
  font-size: var(--font-size-lg);
}

.btn-small {
  padding: var(--space-xs) var(--space-md);
  font-size: var(--font-size-sm);
}

/* Cards */
.card {
  background: white;
  border-radius: var(--radius-lg);
  padding: var(--space-2xl);
  box-shadow: var(--shadow-md);
  transition: all var(--transition-normal);
}

.card:hover {
  transform: translateY(-4px);
  box-shadow: var(--shadow-xl);
  border-left: 4px solid var(--color-primary);
}

.card-header {
  margin-bottom: var(--space-lg);
}

.card-title {
  font-size: var(--font-size-2xl);
  margin-bottom: var(--space-md);
}

.card-body {
  font-size: var(--font-size-base);
}

/* Grid Layouts */
.grid {
  display: grid;
  gap: var(--space-lg);
}

.grid-2 {
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
}

.grid-3 {
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
}

.grid-4 {
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
}

/* Utility Classes - Spacing */
.mt-sm { margin-top: var(--space-sm); }
.mt-md { margin-top: var(--space-md); }
.mt-lg { margin-top: var(--space-lg); }
.mt-xl { margin-top: var(--space-xl); }
.mt-2xl { margin-top: var(--space-2xl); }
.mt-3xl { margin-top: var(--space-3xl); }

.mb-sm { margin-bottom: var(--space-sm); }
.mb-md { margin-bottom: var(--space-md); }
.mb-lg { margin-bottom: var(--space-lg); }
.mb-xl { margin-bottom: var(--space-xl); }
.mb-2xl { margin-bottom: var(--space-2xl); }
.mb-3xl { margin-bottom: var(--space-3xl); }

/* Utility Classes - Typography */
.text-center { text-align: center; }
.text-left { text-align: left; }
.text-right { text-align: right; }

.text-primary { color: var(--color-primary); }
.text-secondary { color: var(--color-secondary); }
.text-muted { color: var(--color-text-muted); }

.text-bold { font-weight: var(--font-weight-bold); }
.text-italic { font-style: italic; }

.text-sm { font-size: var(--font-size-sm); }
.text-lg { font-size: var(--font-size-lg); }
.text-xl { font-size: var(--font-size-xl); }

/* Utility Classes - Layout */
.w-full { width: 100%; }
.max-w-prose { max-width: 65ch; margin-left: auto; margin-right: auto; }

.flex { display: flex; }
.items-center { align-items: center; }
.justify-center { justify-content: center; }
.justify-between { justify-content: space-between; }
.gap-sm { gap: var(--space-sm); }
.gap-md { gap: var(--space-md); }
.gap-lg { gap: var(--space-lg); }

.hidden { display: none; }
```

**Best Practices**:
- Components follow BEM-like naming
- Utility classes for common patterns
- Avoid inline styles in HTML
- Use CSS custom properties for all values

## 5. print.css - Print Styles

**Purpose**: Print-specific styles for better printed output.

```css
@media print {
  /* Hide non-essential elements */
  header,
  nav,
  .cookie-banner,
  .btn,
  .no-print {
    display: none;
  }

  /* Adjust layout for print */
  body {
    font-size: 12pt;
    color: black;
    background: white;
  }

  a {
    text-decoration: underline;
  }

  /* Show URLs after links */
  a[href]:after {
    content: " (" attr(href) ")";
    font-size: 0.8em;
  }

  /* Page breaks */
  h1, h2, h3 {
    page-break-after: avoid;
  }

  /* Avoid breaking inside elements */
  .card,
  .section {
    page-break-inside: avoid;
  }
}
```

## CSS Best Practices

### ✅ Do:

- **Use CSS custom properties** for all design tokens
- **Follow the cascade order** exactly as documented
- **Group related properties** together
- **Comment complex selectors** for clarity
- **Use semantic class names** (`.nav-link` not `.blue-text`)
- **Prefer utility classes** over inline styles
- **Test responsive breakpoints** thoroughly
- **Validate with CSS linters** (stylelint)

### ❌ Don't:

- **Change concatenation order** - breaks cascade
- **Add inline styles** in HTML content files
- **Use `!important` unnecessarily** - indicates specificity issue
- **Hard-code colors** - use variables instead
- **Forget vendor prefixes** for newer properties
- **Neglect mobile** - always mobile-first
- **Skip comments** on complex code

## Debugging CSS Issues

### Common Problems:

**1. Styles not applying:**
- Check file concatenation order
- Verify CSS custom property is defined
- Inspect specificity conflicts
- Rebuild: `python build.py {sitename}`

**2. Responsive issues:**
- Test all breakpoints
- Check mobile-first approach
- Verify viewport meta tag in base.html

**3. Colors/spacing inconsistent:**
- Use defined CSS custom properties
- Don't hard-code values
- Check variables.css is loaded first

**4. Layout breaking:**
- Validate HTML structure
- Check container nesting
- Inspect grid/flexbox properties
- Use browser DevTools

## CSS Modifications Workflow

When modifying CSS:

1. **Identify which file** to edit based on purpose
2. **Update CSS custom properties** if changing design tokens
3. **Follow existing patterns** in that file
4. **Test locally** with `python serve.py {sitename}`
5. **Validate on all pages**, not just homepage
6. **Rebuild** before deploying: `python build.py {sitename}`
7. **Deploy** with `./deploy.sh {sitename} "message"`
