#!/usr/bin/env python3
"""
CSS Analyzer for Boilerplate Sites

Analyzes CSS files for common issues:
- Unused CSS custom properties
- Hard-coded values that should use variables
- Specificity issues
- Missing fallbacks
- Inline styles in HTML (if HTML paths provided)
- CSS file size analysis

Usage:
    python analyze-css.py <site_path>
    python analyze-css.py sites/carbonellestrany/src
"""

import os
import sys
import re
from pathlib import Path
from collections import defaultdict


def read_file(filepath):
    """Read file content safely."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return None


def extract_css_variables(content):
    """Extract all CSS custom properties defined in content."""
    pattern = r'--[\w-]+(?=\s*:)'
    return set(re.findall(pattern, content))


def find_css_variable_usage(content):
    """Find all var() usages in CSS."""
    pattern = r'var\((--[\w-]+)(?:,\s*[^)]+)?\)'
    return set(re.findall(pattern, content))


def find_hard_coded_colors(content):
    """Find hard-coded color values that should use variables."""
    # Hex colors
    hex_pattern = r'#[0-9a-fA-F]{3,8}(?![^{]*var\()'
    # RGB/RGBA colors
    rgb_pattern = r'rgba?\([^)]+\)'

    hex_colors = re.findall(hex_pattern, content)
    rgb_colors = re.findall(rgb_pattern, content)

    return hex_colors + rgb_colors


def find_hard_coded_spacing(content):
    """Find hard-coded spacing values (px, rem, em)."""
    pattern = r'(?:margin|padding|gap|width|height|top|bottom|left|right):\s*(\d+(?:\.\d+)?(?:px|rem|em))'
    return re.findall(pattern, content)


def find_inline_styles(content):
    """Find inline style attributes in HTML."""
    pattern = r'style=["\'][^"\']+["\']'
    return re.findall(pattern, content)


def analyze_css_files(site_path):
    """Analyze all CSS files in the site."""
    css_dir = Path(site_path) / 'static' / 'css'

    if not css_dir.exists():
        print(f"❌ CSS directory not found: {css_dir}")
        return

    print("=" * 70)
    print(f"CSS Analysis: {site_path}")
    print("=" * 70)
    print()

    # Read all CSS files
    css_files = {
        'variables.css': css_dir / 'variables.css',
        'reset.css': css_dir / 'reset.css',
        'main.css': css_dir / 'main.css',
        'components.css': css_dir / 'components.css',
        'print.css': css_dir / 'print.css',
    }

    css_contents = {}
    total_size = 0

    for name, filepath in css_files.items():
        if filepath.exists():
            content = read_file(filepath)
            if content:
                css_contents[name] = content
                size = len(content.encode('utf-8'))
                total_size += size
                print(f"✓ {name}: {size:,} bytes")
        else:
            print(f"⚠ {name}: Not found")

    print(f"\nTotal CSS size: {total_size:,} bytes")
    print()

    # Analyze variables
    if 'variables.css' in css_contents:
        defined_vars = extract_css_variables(css_contents['variables.css'])
        print(f"📊 CSS Custom Properties Defined: {len(defined_vars)}")

        # Find used variables across all files
        used_vars = set()
        for name, content in css_contents.items():
            if name != 'variables.css':
                used_vars.update(find_css_variable_usage(content))

        print(f"📊 CSS Custom Properties Used: {len(used_vars)}")

        # Unused variables
        unused_vars = defined_vars - used_vars
        if unused_vars:
            print(f"\n⚠ Unused Variables ({len(unused_vars)}):")
            for var in sorted(unused_vars)[:10]:  # Show first 10
                print(f"  - {var}")
            if len(unused_vars) > 10:
                print(f"  ... and {len(unused_vars) - 10} more")
        else:
            print("\n✓ All defined variables are used")

        # Variables used but not defined
        undefined_vars = used_vars - defined_vars
        if undefined_vars:
            print(f"\n❌ Variables Used But Not Defined ({len(undefined_vars)}):")
            for var in sorted(undefined_vars):
                print(f"  - {var}")
        else:
            print("✓ All used variables are defined")

    print()

    # Check for hard-coded values
    print("🔍 Hard-Coded Values Analysis")
    print("-" * 70)

    for name, content in css_contents.items():
        if name == 'variables.css':
            continue  # Skip variables file for this check

        # Hard-coded colors
        colors = find_hard_coded_colors(content)
        if colors:
            print(f"\n⚠ {name} - Hard-coded colors ({len(colors)}):")
            unique_colors = list(set(colors))[:5]
            for color in unique_colors:
                print(f"  - {color}")
            if len(unique_colors) > 5:
                print(f"  ... and {len(colors) - 5} more")

        # Hard-coded spacing
        spacing = find_hard_coded_spacing(content)
        if spacing and len(spacing) > 5:  # Only warn if many hard-coded values
            print(f"\n⚠ {name} - Hard-coded spacing values ({len(spacing)})")
            print("  Consider using CSS custom properties from variables.css")

    print()


def analyze_html_files(site_path):
    """Analyze HTML content files for inline styles."""
    content_dir = Path(site_path) / 'content'

    if not content_dir.exists():
        print(f"⚠ Content directory not found: {content_dir}")
        return

    print()
    print("🔍 HTML Inline Styles Analysis")
    print("-" * 70)

    inline_styles_found = False

    for html_file in content_dir.rglob('*.html'):
        content = read_file(html_file)
        if content:
            inline_styles = find_inline_styles(content)
            if inline_styles:
                inline_styles_found = True
                rel_path = html_file.relative_to(site_path)
                print(f"\n❌ {rel_path} - Inline styles found ({len(inline_styles)}):")
                for style in inline_styles[:3]:
                    print(f"  - {style[:60]}...")
                if len(inline_styles) > 3:
                    print(f"  ... and {len(inline_styles) - 3} more")

    if not inline_styles_found:
        print("\n✓ No inline styles found in HTML files")

    print()


def main():
    """Main analysis function."""
    if len(sys.argv) < 2:
        print("Usage: python analyze-css.py <site_path>")
        print("Example: python analyze-css.py sites/carbonellestrany/src")
        sys.exit(1)

    site_path = sys.argv[1]

    if not os.path.exists(site_path):
        print(f"❌ Path not found: {site_path}")
        sys.exit(1)

    analyze_css_files(site_path)
    analyze_html_files(site_path)

    print("=" * 70)
    print("Analysis complete!")
    print("=" * 70)


if __name__ == '__main__':
    main()
