#!/usr/bin/env python3
"""
Structure Validator for Boilerplate Sites

Validates that site follows boilerplate architecture:
- Required directories exist
- CSS files are present and in correct locations
- Configuration files are valid JSON
- Templates exist
- Content files organized correctly

Usage:
    python validate-structure.py <site_path>
    python validate-structure.py sites/carbonellestrany/src
"""

import os
import sys
import json
from pathlib import Path


class bcolors:
    """Terminal colors for output."""
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


def check_directory(path, name):
    """Check if directory exists."""
    if path.exists() and path.is_dir():
        print(f"  {bcolors.OKGREEN}✓{bcolors.ENDC} {name}")
        return True
    else:
        print(f"  {bcolors.FAIL}✗{bcolors.ENDC} {name} - Missing")
        return False


def check_file(path, name, required=True):
    """Check if file exists."""
    if path.exists() and path.is_file():
        size = path.stat().st_size
        print(f"  {bcolors.OKGREEN}✓{bcolors.ENDC} {name} ({size:,} bytes)")
        return True
    else:
        if required:
            print(f"  {bcolors.FAIL}✗{bcolors.ENDC} {name} - Missing (required)")
        else:
            print(f"  {bcolors.WARNING}⚠{bcolors.ENDC} {name} - Missing (optional)")
        return False


def validate_json_file(path, name):
    """Validate JSON file is properly formatted."""
    if not path.exists():
        print(f"  {bcolors.FAIL}✗{bcolors.ENDC} {name} - Missing")
        return False

    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        print(f"  {bcolors.OKGREEN}✓{bcolors.ENDC} {name} - Valid JSON")
        return True
    except json.JSONDecodeError as e:
        print(f"  {bcolors.FAIL}✗{bcolors.ENDC} {name} - Invalid JSON: {e}")
        return False
    except Exception as e:
        print(f"  {bcolors.FAIL}✗{bcolors.ENDC} {name} - Error: {e}")
        return False


def validate_structure(site_path):
    """Validate complete site structure."""
    site_path = Path(site_path)

    print("=" * 70)
    print(f"{bcolors.HEADER}{bcolors.BOLD}Structure Validation: {site_path}{bcolors.ENDC}")
    print("=" * 70)
    print()

    total_checks = 0
    passed_checks = 0

    # 1. Root directories
    print(f"{bcolors.OKBLUE}📁 Root Directories{bcolors.ENDC}")
    dirs = [
        (site_path / 'content', 'content/'),
        (site_path / 'templates', 'templates/'),
        (site_path / 'static', 'static/'),
        (site_path / 'data', 'data/'),
    ]
    for path, name in dirs:
        total_checks += 1
        if check_directory(path, name):
            passed_checks += 1
    print()

    # 2. CSS files
    print(f"{bcolors.OKBLUE}📄 CSS Files (static/css/){bcolors.ENDC}")
    css_dir = site_path / 'static' / 'css'
    css_files = [
        ('variables.css', True),
        ('reset.css', True),
        ('main.css', True),
        ('components.css', True),
        ('print.css', True),
    ]
    for filename, required in css_files:
        total_checks += 1
        if check_file(css_dir / filename, filename, required):
            passed_checks += 1
    print()

    # 3. JavaScript files
    print(f"{bcolors.OKBLUE}📄 JavaScript Files (static/js/){bcolors.ENDC}")
    js_dir = site_path / 'static' / 'js'
    js_files = [
        ('main.js', True),
        ('cookie-consent.js', True),
        ('lazy-load.js', False),
        ('analytics.js', False),
    ]
    for filename, required in js_files:
        total_checks += 1
        if check_file(js_dir / filename, filename, required):
            passed_checks += 1
    print()

    # 4. Images directory
    print(f"{bcolors.OKBLUE}📁 Images Directory{bcolors.ENDC}")
    images_dir = site_path / 'static' / 'images'
    total_checks += 1
    if check_directory(images_dir, 'static/images/'):
        passed_checks += 1

    # Check for logo
    logo_files = ['logo.png', 'logo.svg', 'logo.jpg']
    logo_found = False
    for logo in logo_files:
        if (images_dir / logo).exists():
            print(f"  {bcolors.OKGREEN}✓{bcolors.ENDC} Logo found: {logo}")
            logo_found = True
            break
    if not logo_found:
        print(f"  {bcolors.WARNING}⚠{bcolors.ENDC} No logo file found (logo.png recommended)")
    print()

    # 5. Templates
    print(f"{bcolors.OKBLUE}📄 Templates{bcolors.ENDC}")
    templates = [
        (site_path / 'templates' / 'base.html', 'base.html', True),
        (site_path / 'templates' / 'components' / 'header.html', 'components/header.html', True),
        (site_path / 'templates' / 'components' / 'footer.html', 'components/footer.html', True),
        (site_path / 'templates' / 'components' / 'cookie-banner.html', 'components/cookie-banner.html', False),
    ]
    for path, name, required in templates:
        total_checks += 1
        if check_file(path, name, required):
            passed_checks += 1
    print()

    # 6. Configuration files
    print(f"{bcolors.OKBLUE}📄 Configuration Files (data/){bcolors.ENDC}")
    data_dir = site_path / 'data'
    config_files = [
        'config.json',
        'ui-strings.json',
        'navigation.json',
        'page-metadata.json',
    ]
    for filename in config_files:
        total_checks += 1
        if validate_json_file(data_dir / filename, filename):
            passed_checks += 1
    print()

    # 7. Content directories
    print(f"{bcolors.OKBLUE}📁 Content Directories{bcolors.ENDC}")
    content_dir = site_path / 'content'
    if content_dir.exists():
        langs = [d for d in content_dir.iterdir() if d.is_dir()]
        if langs:
            print(f"  Languages found: {len(langs)}")
            for lang_dir in langs:
                lang = lang_dir.name
                html_files = list(lang_dir.glob('*.html'))
                total_checks += 1
                if html_files:
                    print(f"  {bcolors.OKGREEN}✓{bcolors.ENDC} {lang}/ - {len(html_files)} HTML files")
                    passed_checks += 1
                else:
                    print(f"  {bcolors.WARNING}⚠{bcolors.ENDC} {lang}/ - No HTML files found")
        else:
            print(f"  {bcolors.FAIL}✗{bcolors.ENDC} No language directories found")
    print()

    # 8. CSS Concatenation Order Check
    print(f"{bcolors.OKBLUE}🔍 CSS Concatenation Order{bcolors.ENDC}")
    css_order = ['variables.css', 'reset.css', 'main.css', 'components.css', 'print.css']
    order_correct = True
    for i, filename in enumerate(css_order, 1):
        filepath = css_dir / filename
        if filepath.exists():
            print(f"  {i}. {filename} {bcolors.OKGREEN}✓{bcolors.ENDC}")
        else:
            print(f"  {i}. {filename} {bcolors.FAIL}✗{bcolors.ENDC}")
            order_correct = False

    if order_correct:
        print(f"  {bcolors.OKGREEN}✓{bcolors.ENDC} CSS files exist in correct order")
    print()

    # Summary
    print("=" * 70)
    percentage = (passed_checks / total_checks * 100) if total_checks > 0 else 0
    color = bcolors.OKGREEN if percentage >= 90 else (bcolors.WARNING if percentage >= 70 else bcolors.FAIL)

    print(f"{bcolors.BOLD}Summary:{bcolors.ENDC}")
    print(f"  Passed: {color}{passed_checks}/{total_checks}{bcolors.ENDC} ({percentage:.1f}%)")

    if percentage == 100:
        print(f"\n{bcolors.OKGREEN}{bcolors.BOLD}✓ Site structure is valid!{bcolors.ENDC}")
    elif percentage >= 90:
        print(f"\n{bcolors.WARNING}⚠ Site structure is mostly valid with minor issues{bcolors.ENDC}")
    else:
        print(f"\n{bcolors.FAIL}✗ Site structure has significant issues{bcolors.ENDC}")

    print("=" * 70)

    return percentage >= 90


def main():
    """Main validation function."""
    if len(sys.argv) < 2:
        print("Usage: python validate-structure.py <site_path>")
        print("Example: python validate-structure.py sites/carbonellestrany/src")
        sys.exit(1)

    site_path = sys.argv[1]

    if not os.path.exists(site_path):
        print(f"{bcolors.FAIL}❌ Path not found: {site_path}{bcolors.ENDC}")
        sys.exit(1)

    success = validate_structure(site_path)
    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()
